import { Component, OnInit, Input } from '@angular/core';
import { Relationship } from '../relationship/relationship.model';
import { UserService } from '../user/user.service';
import { User } from '../user/user.model';
import { element } from 'protractor';

@Component({
  selector: 'app-user-name2',
  templateUrl: './user-name2.component.html',
  styleUrls: ['./user-name2.component.css']
})
export class UserName2Component implements OnInit {
  @Input() relation: Relationship;
  userList: User[];
  user: User;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.relation = new Relationship();
    this.user = new User();
    this.userList = new Array<User>();

    this.userService.getUser().subscribe((data: User[]) => this.userList = data,
      error => console.error('no se carga el usuario desde userName2'), () => console.log('User List desde userName2'));
  }

  getName(relation: Relationship) {
    let user = new User();
    this.userList.forEach(element => {
      if (element.id == relation.idUser2) {
        user = element;
        
      }
    });
    // return this.user.name + ' ' + this.user.surname;
    return user.name;
  }
  getImage(relation:Relationship){
    let user = new User();
    this.userList.forEach(element => {
      if (element.id == relation.idUser2) {
        user = element;
      }
    });
    return user.image;
  }









}
