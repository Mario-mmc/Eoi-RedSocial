import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllHistoriesComponent } from './all-histories.component';

describe('AllHistoriesComponent', () => {
  let component: AllHistoriesComponent;
  let fixture: ComponentFixture<AllHistoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllHistoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllHistoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
