import { Component, OnInit } from '@angular/core';
import { Histories } from './histories.model';
import { HistoriesService } from './histories.service';
import { UserService } from '../user/user.service';
import { User } from '../user/user.model';


@Component({
  selector: 'app-histories',
  templateUrl: './histories.component.html',
  styleUrls: ['./histories.component.css']
})
export class HistoriesComponent implements OnInit {
  history:Histories;
  histories:Histories[];
  user:User;
  userList:User[];
  myHistories:Histories[];

  constructor(private historiesService:HistoriesService, private userService:UserService) { }

  ngOnInit() {
    this.history = new Histories();
    this.user= new User();
    this.myHistories = new Array();

    this.userService.getUser().subscribe((data:User[])=> this.userList = data,
    error => console.error(error), () => console.log('User List is loaded!'))
    
    this.historiesService.getHistories().subscribe((data: Histories[]) => this.histories = data,
    error => console.error(error), () => console.log('History List is loaded!'));
    
    this.historiesService.getMainHistories().subscribe((data:Histories) => this.history= data,
    error => console.log('error'), () => console.log('Main History loaded!'));
  }

  addHistory(history:Histories){
    this.historiesService.addHistories(history);
  }

  getHistories(){
    this.historiesService.getHistories();
  }
  getMainHistories(){
    this.historiesService.getMainHistories();
  }

  getHistoryByUser(user:User){
  
    this.histories.forEach(element =>{
      if(user.id == element.idUser){
        this.myHistories.push(element);
      }
    });
    return this.myHistories;
    

  }

  getHistoryById(id:number){
    return this.historiesService.getHistoriesById(id);
  }
  




}
