import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Histories } from './histories.model';
import { Observable } from 'rxjs';

const URL_BASE:string = 'http://localhost:3000/Histories';

const httpOptions ={
    headers: new HttpHeaders({
        'Content-Type':'application/json',
        'Authorization':'my-auth-token'
    })
  };

@Injectable()
export class HistoriesService {
  

  constructor(private http:HttpClient) { }
  
  ngOnInit(){
    
  }
  
  
  
  getHistories(){
    return this.http.get('http://localhost:3000/histories');
}
getMainHistories(){
  return this.http.get('http://localhost:3000/histories?idUser=1');
}

updateHistories(history:Histories):Observable<Histories>{
  const url =`${URL_BASE}/${history.id}`;
  return this.http.put<Histories>(url, history, httpOptions);
 }

 addHistories(history:Histories):Observable<Histories>{
   console.log('has llegado al metodo del servicio');
  return this.http.post<Histories>(URL_BASE,history,httpOptions);
}

getHistoriesById(id:number){
  return this.http.get(`http://localhost:3000/histories/${id}`);
}
deleteHistory(history:Histories):Observable<Histories>{

  const url =`${URL_BASE}/${history.id}`;
  return this.http.delete<Histories>(url);
 }
}
