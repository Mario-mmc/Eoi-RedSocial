import { User } from '../user/user.model';

export class Histories{
    id:number;
    contain:string;
    idUser:number;
    date?:Date;
}