import { Component, OnInit } from '@angular/core';
import { Histories } from '../histories/histories.model';
import { HistoriesService } from '../histories/histories.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-history',
  templateUrl: './create-history.component.html',
  styleUrls: ['./create-history.component.css']
})
export class CreateHistoryComponent implements OnInit {
  history:Histories;

  constructor(private historiesService:HistoriesService, private router:Router) { }

  ngOnInit() {
    this.history = new Histories();
    this.history.idUser = 1;
    

    
  }

  createHistory(){
    this.historiesService.addHistories(this.history).subscribe((data:Histories) => this.history = data,
    error => console.log('error'), () => window.location.reload());
    
    
  }
  

}
