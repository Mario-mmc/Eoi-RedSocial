export class Relationship{
    id:number;
    idUser1:number;
    idUser2:number;
    status:string;
}