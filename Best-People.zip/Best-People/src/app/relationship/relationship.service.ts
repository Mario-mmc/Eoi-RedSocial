import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Relationship } from './relationship.model';
import { Observable } from 'rxjs';
import { User } from '../user/user.model';

const URL_BASE:string = 'http://localhost:3000/relationship';

  const httpOptions ={
      headers: new HttpHeaders({
          'Content-Type':'application/json',
          'Authorization':'my-auth-token'
      })
    };
@Injectable()
export class RelationshipService {
  
  constructor(private http:HttpClient) { }

  getRelationships(){
    return this.http.get('http://localhost:3000/relationship');
}
getMainRelationships(){
  return this.http.get('http://localhost:3000/relationship?idUser*=1');
}

updateRelationShip(relationship:Relationship):Observable<Relationship>{
  const url =`${URL_BASE}/${relationship.id}`;
  return this.http.put<Relationship>(url, relationship, httpOptions);
 }

 addUser(relationship:Relationship):Observable<Relationship>{
  return this.http.post<Relationship>(URL_BASE,relationship,httpOptions);
}
getRelationshipById(id:number){
  return this.http.get(`http://localhost:3000/relationship/${id}`);
}
addRelationship(relationship:Relationship):Observable<Relationship>{
  
 return this.http.post<Relationship>(URL_BASE,history,httpOptions);
}
deleteRelationship(relationship:Relationship):Observable<Relationship>{

  const url =`${URL_BASE}/${relationship.id}`;
  return this.http.delete<Relationship>(url);
 }


}
