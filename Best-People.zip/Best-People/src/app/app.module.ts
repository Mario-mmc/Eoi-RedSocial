import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { UserComponent } from './user/user.component';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from './user/user.service';
import { HistoriesComponent } from './histories/histories.component';
import { HistoriesService } from './histories/histories.service';
import { CreateHistoryComponent } from './create-history/create-history.component';
import { FormsModule } from '@angular/forms';
import { HistoriasComponent } from './HISTORIAS/historias.component';
import { MisCosasComponent } from './MIS- COSAS/mis-cosas.component';
import { AmigosComponent } from './AMIGOS/amigos.component';
import { routing } from './app.routes';
import { MyHistoriesComponent } from './my-histories/my-histories.component';
import { AllHistoriesComponent } from './all-histories/all-histories.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { RelationshipService } from './relationship/relationship.service';
import { UserNameComponent } from './user-name/user-name.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { PeopleComponent } from './people/people.component';
import { UserName2Component } from './user-name2/user-name2.component';




@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    UserComponent,
    HistoriesComponent,
    CreateHistoryComponent,
    HistoriasComponent,
    MisCosasComponent,
    AmigosComponent,
    MyHistoriesComponent,
    AllHistoriesComponent,
    RelationshipComponent,
    UserNameComponent,
    HeaderComponent,
    FooterComponent,
    PeopleComponent,
    UserName2Component
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    routing
  ],
  providers: [
    UserService,
    HistoriesService,
    RelationshipService
  ],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
