export class User{
    id:number;
    name:string;
    surname:string;
    image?:string;
    history?:string;
    friends?:User[];
}