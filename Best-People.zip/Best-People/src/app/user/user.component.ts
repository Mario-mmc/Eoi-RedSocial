import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { User } from './user.model';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user:User;
  userList:User[];
  constructor(private userService:UserService) { }

  ngOnInit() {
    this.user= new User();

    this.userService.getUser().subscribe((data: User[]) => this.userList = data,
    error => console.error(error), () => console.log('User List is loaded!'));
    
    this.userService.getMainUser().subscribe((data:User) => this.user = data,
    error => console.log('error'), () => console.log('Main User loaded!'));
  }
  addUser(user:User){
    this.userService.addUser(user);
  }

}
