import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../user/user.service';
import { User } from '../user/user.model';
import { Relationship } from '../relationship/relationship.model';
import { Histories } from '../histories/histories.model';

@Component({
  selector: 'app-user-name',
  templateUrl: './user-name.component.html',
  styleUrls: ['./user-name.component.css']
})
export class UserNameComponent implements OnInit {
  userList: User[];
  user: User;
  @Input() history:Histories;
  @Input() relation:Relationship;
  constructor(private userService: UserService) { }

  ngOnInit() {
    this.relation = new Relationship();
    
    this.user = new User();
    this.userList = new Array<User>();
    
    this.userService.getUser().subscribe((data: User[]) => this.userList = data,
      error => console.error(error), () => console.log('User List is loaded!'));
  }

  getName(history:Histories){
    let user = new User();
    this.userList.forEach(element => {
      if (element.id == history.idUser){
        user = element;
      }
    });
    
    return user.name +' ' + user.surname;
  }
  

  getImage(history:Histories){
    let user = new User();
    this.userList.forEach(element => {
      if (element.id == history.idUser){
        user = element;
      }
    });
    
    return user.image;
  }
  

}
